﻿using System;

namespace UnityWebGLSpeechSynthesis
{
    [Serializable]
    public class VoiceResult
    {
        public Voice[] voices;
    }
}
