using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AnimationAction : MonoBehaviour
{
    public bool IsOnec = true;
    public bool IsStartRun = false;
    private bool IsRun;
    // Start is called before the first frame update
    void Start()
    {
        if (IsStartRun)
        {
            Run();
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void Run()
    {
        if (IsRun) return;

        Animation animation = GetComponent<Animation>();
        if (animation != null)
        {
            animation.Play(animation.clip.name);
        }

        if (IsOnec)
        {
            IsRun = true;
        }
    }
}
