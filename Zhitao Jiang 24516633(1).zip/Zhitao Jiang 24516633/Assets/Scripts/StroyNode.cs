﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

public class StroyNode : MonoBehaviour
{
    public GameObject[] Parts;
    private int CurrPartIndex;
    public void ActiveNode(bool isActive)
    {
        gameObject.SetActive(isActive);
    }

    public void LeftNext()
    {
        CurrPartIndex--;
        if (CurrPartIndex < 0)
        {
            CurrPartIndex = 0;
            return;
        }

        for (int i = 0; i < Parts.Length; i++)
        {
            Parts[i].SetActive(CurrPartIndex == i);
        }

        AudioTool.Stop();
    }

    public void RightNext() 
    {
        CurrPartIndex++;
        if (CurrPartIndex >= Parts.Length)
        {
            CurrPartIndex = Parts.Length - 1;
            return;
        }

        for(int i = 0;i < Parts.Length; i++)
        {
            Parts[i].SetActive(CurrPartIndex == i);
        }

        AudioTool.Stop();
    }

    public string GetSpeakText()
    {
        SpeakTextBtn speakTextBtn = Parts[CurrPartIndex].GetComponentInChildren<SpeakTextBtn>();
        return speakTextBtn.GetSpeakText();
    }
}
