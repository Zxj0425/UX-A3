﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine.UI;

[UnityEngine.RequireComponent(typeof(Text))]
public class SpeakTextBtn : Button
{
    private Text text;
    protected override void Awake()
    {
        base.Awake();
        text = GetComponent<Text>();
    }

    protected override void Start()
    {
        onClick.AddListener(() =>
        {
            if(text != null)
            {
                AudioTool.Stop();
                AudioTool.Speak(text.text);
            }
        });
    }

    public string GetSpeakText()
    {
        return text.text;
    }
}
