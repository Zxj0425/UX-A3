using Crosstales.RTVoice.Tool;
using Crosstales.RTVoice.Util;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityWebGLSpeechSynthesis;

public enum StroyType
{
    StroyOne,
    StroyTwo,
    StroyThree,
    StroyFour,
    StroyFive,
}

[Serializable]
public class ButtonSpriteData
{
    public Sprite LeftBtn;
    public Sprite RightBtn;
    public Sprite ReadBtn;
    public Sprite HomeBtn;
    public Sprite MenuBtn;
    public Sprite StartBtn;
}

public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get;private set; }

    [Header("Speak")]
    public Example01Synthesis SpeechText;
    public SpeechText SpeechText1;

    public AudioSource AudioSource;

    [Header("Stroy")]
    public AudioClip[] AllAudioClips;
    public ButtonSpriteData[] ButtonSprites;
    public StroyNode[] AllStroyNode;
    public StroyType StroyType;

    [Header("UI")]
    public Button LeftBtn;
    public Button RightBtn;
    public Button SpeakBtn;
    public Button GoHomeBtn;
    public Button MenuBtn;
    public Button StartBtn;


    public AudioSource FanShuAudio;


    private void Awake()
    {
        Instance = this;
    }

    private void Start()
    {
        InitStroyNode();
    }

    public void Init()
    {
        //InitStroyNode();
    }

    private void InitStroyNode()
    {
        SpeakBtn.onClick.RemoveAllListeners();
        SpeakBtn.onClick.AddListener(() =>
        {
            AudioTool.Stop();
            StroyNode stroyNode = AllStroyNode[(int)StroyType];
            AudioTool.Speak(stroyNode.GetSpeakText());
        });
        GoHomeBtn.onClick.RemoveAllListeners();
        GoHomeBtn.onClick.AddListener(() =>
        {
            AudioTool.Stop();
            if (StroyType != StroyType.StroyFive)
            {
                SceneManager.LoadScene(SceneManager.GetActiveScene().name);
            }
        });

        for (int i = 0; i < AllStroyNode.Length; i++)
        {
            if ((int)StroyType == i)
            {
                AllStroyNode[i].ActiveNode(true);
                LeftBtn.onClick.RemoveAllListeners();
                LeftBtn.onClick.AddListener(AllStroyNode[i].LeftNext);
                LeftBtn.onClick.AddListener(() =>
                {
                    FanShuAudio.Play();
                });
                RightBtn.onClick.RemoveAllListeners();
                RightBtn.onClick.AddListener(AllStroyNode[i].RightNext);
                RightBtn.onClick.AddListener(() =>
                {
                    FanShuAudio.Play();
                });
            }
            else
            {
                AllStroyNode[i].ActiveNode(false);
            }
        }

        if (AudioSource)
        {
            AudioSource.clip = AllAudioClips[(int)StroyType];
            AudioSource.loop = true;
            AudioSource.Play();
        }

        if (ButtonSprites.Length != AllStroyNode.Length) return;

        var data = ButtonSprites[(int)StroyType];
        LeftBtn.GetComponent<Image>().sprite = data.LeftBtn;
        RightBtn.GetComponent<Image>().sprite = data.RightBtn;
        SpeakBtn.GetComponent<Image>().sprite = data.ReadBtn;
        GoHomeBtn.GetComponent<Image>().sprite = data.HomeBtn;
        MenuBtn.GetComponent<Image>().sprite = data.MenuBtn;
        StartBtn.GetComponent<Image>().sprite = data.StartBtn;

        FiveTemp();
    }

    public void GoHome()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    public void FiveTemp()
    {
        StartBtn.onClick.AddListener(() =>
        {
            if (StroyType == StroyType.StroyFive)
            {
                AllStroyNode[4].RightNext();
            }
        });
    }
}

public static class AudioTool
{
    public static void Speak(string context)
    {
        AudioTool.Stop();

#if UNITY_EDITOR
        if (GameManager.Instance.SpeechText1 != null)
        {
            GameManager.Instance.SpeechText1.Text = context;
            GameManager.Instance.SpeechText1.Speak();
        }
#else
        if (GameManager.Instance.SpeechText != null)
        {
            GameManager.Instance.SpeechText.SpeakText(context);
        }
#endif
    }

    public static void Stop()
    {
#if UNITY_EDITOR
        if (GameManager.Instance.SpeechText1 != null)
        {
            GameManager.Instance.SpeechText1.Silence();
        }
#else
        if (GameManager.Instance.SpeechText != null)
        {
            GameManager.Instance.SpeechText.Stop();
        }
#endif
    }
}
