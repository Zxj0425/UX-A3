﻿# crosstales LLC - Common package 2023.1.0

## Description
This folder and its content is needed for all assets from "crosstales LLC".

Please DO NOT DELETE anything except the "Extras" or the assets will not work anymore!



## Important:
If the demo scenes of our assets look wrong ("Missing Prefabs", graphics missing etc.) please re-import "UI.unitypackage".



## Notes:
The "Extras"-folder contains many packages that enhance your app.
Please see the README for more information. 



## Contact

crosstales LLC
Schanzeneggstrasse 1
CH-8002 Zürich

* [Homepage](https://www.crosstales.com/)
* [Email](mailto:assets@crosstales.com)

### Social media
* [Facebook](https://www.facebook.com/crosstales/)
* [Twitter](https://twitter.com/crosstales)
* [LinkedIN](https://www.linkedin.com/company/crosstales)



## More information
* [AssetStore](https://assetstore.unity.com/lists/crosstales-42213?aid=1011lNGT)
* [Youtube-channel](https://www.youtube.com/c/Crosstales)


`Version: 26.01.2023`