﻿# Random

## Description
This package contains various classes to randomize values of gameobjects:
  * Color
  * Rotation
  * Scale  
