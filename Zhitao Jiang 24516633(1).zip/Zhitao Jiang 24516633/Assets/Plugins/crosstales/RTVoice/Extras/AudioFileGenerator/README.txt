﻿# AudioFileGenerator

## Description
This package contains an audio file generator for text files.
