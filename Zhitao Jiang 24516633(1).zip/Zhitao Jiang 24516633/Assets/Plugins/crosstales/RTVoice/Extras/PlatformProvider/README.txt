﻿# PlatformProvider

## Description
This package allows to configure voice providers per platform.
