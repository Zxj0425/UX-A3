﻿# Sequencer

## Description
This package plays a sequence of texts. 
