﻿# VoiceInitializer

## Description
This package allows to initalize voices before speaking (preventing lag on certain systems like Android).
