﻿# Paralanguage

## Description
This package allows to generate para-language speeches.
