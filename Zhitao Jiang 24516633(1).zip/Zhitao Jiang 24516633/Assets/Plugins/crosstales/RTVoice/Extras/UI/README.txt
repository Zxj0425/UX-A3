﻿# UI

## Description
This package contains classes to speak UI elements like Text and InputField.


## Note
If "TextMesh Pro" is used, please uncomment line 4 in "SpeakUITMPText.cs" and "SpeakUITMPInputField.cs"