﻿# ChangeGender

## Description
This package allows to globally switch the gender (useful for eSpeak).
