# Adventure Creator
Version: 1.76.1
https://assetstore.unity.com/packages/slug/11896?aid=1011lNGT


# Amplitude
Version: 1.1.0
https://assetstore.unity.com/packages/slug/111277?aid=1011lNGT


# AWS Polly
Version: 26.01.2018
https://aws.amazon.com/polly/
https://github.com/aws/aws-sdk-net/files/1669402/AWSPollyMin.zip


# Azure (Bing Speech)
https://docs.microsoft.com/en-us/azure/cognitive-services/Speech/Home


# Cinema Director
Version: 1.4.5.2
https://assetstore.unity.com/packages/slug/19779?aid=1011lNGT


# Dialogue System
Version: current
https://assetstore.unity.com/packages/slug/11672?aid=1011lNGT

Please use the provided example from:
Assets\Dialogue System\Third Party Support\RTVoice Support.unitypackage


# Google Cloud
Version: 1.5.2
https://assetstore.unity.com/packages/slug/115170?aid=1011lNGT


# Klattersynth
Version: 1.0
https://assetstore.unity.com/packages/slug/95453?aid=1011lNGT


# LDC
Version: 5.0
https://assetstore.unity.com/packages/slug/5020?aid=1011lNGT


# LipSync
Version: 1.1
https://assetstore.unity.com/packages/slug/32117?aid=1011lNGT


# Naninovel
Version: 1.15.1
https://assetstore.unity.com/packages/slug/135453?aid=1011lNGT


# NPC Chat
Version: 1.76
https://assetstore.unity.com/packages/slug/9723?aid=1011lNGT


# PlayMaker
Version: 1.9.5
https://assetstore.unity.com/packages/slug/368?aid=1011lNGT


# SALSA
Version: 2.1.0
https://assetstore.unity.com/packages/slug/148442?aid=1011lNGT
For the previous version, see the "SALSAv1.zip"


# SLATE
Version: 1.8.2
https://assetstore.unity.com/packages/slug/56558?aid=1011lNGT


# Volumetric Audio
Version: 1.1.9
https://assetstore.unity.com/packages/slug/17125?aid=1011lNGT


# WebGL Speech Synthesis
Version: 1.5
https://assetstore.unity.com/packages/slug/81861?aid=1011lNGT



# Already working:

## Quest System Pro
https://assetstore.unity.com/packages/slug/63460?aid=1011lNGT
